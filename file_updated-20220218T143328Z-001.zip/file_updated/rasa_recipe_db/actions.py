from typing import Any, Text, Dict, List
#
from rasa_sdk import Action, Tracker
from rasa_sdk.executor import CollectingDispatcher
import requests

#import mysql.connector as sql
import pandas as pd
import numpy as np
import sqlite3
import random

#creating connection
#wamp_server_phpmyadmin_database
#db_connection = sql.connect(host='localhost', database='test_db', user='root', password='')

#sqlite database
db_connection = sqlite3.connect('recipes_db.sqlite')
db_cursor = db_connection.cursor()

print("connection_established")
#fetching sinle "customer_histories table from mysql database
db_cursor.execute('SELECT * FROM recipes')
sql_data1 = db_cursor.fetchall()

#creating dataframe for "customer_histories"
df1=pd.DataFrame(sql_data1)
df1.columns=[x[0] for x in db_cursor.description]
print(df1.head())

#converting "custmer histories" dataframe to CSV
#df1.to_csv('recipes_data_f.csv', index=False)

"""
class ActionDbIngredients(Action):
 
    def name(self):
      return "action_ingredients"

    def run(self, dispatcher, tracker, domain):
      
      var ="ingredients to cook MOB'S PULLED CHICKEN BURGER"
      conditions=tracker.get_slot('food')
      input_str = tracker.latest_message.get("text")
      print("xyz", input_str)
      df_dish_all_rows = df1[df1['dish'].str.contains(conditions.upper())] 
      data_ingredients_list =list(df_dish_all_rows['ingredients'])
      #print("1111111",data_ingredients_list)
      data_ingredients_random = np.random.choice(data_ingredients_list)
      print("222222222",data_ingredients_random)

      msg = "Ingredients for selected {}! Ingredients: {}:".format(conditions,data_ingredients_random)
      dispatcher.utter_message(msg)
      return []
      
      
"""


class ActionDbIngredients(Action):
 
    def name(self):
      return "action_ingredients"

    def run(self, dispatcher, tracker, domain):
      

      conditions=tracker.get_slot('food')
      print("xyz22222222", conditions)
      df_dish_all_rows = df1[df1['dish'].str.contains(conditions.upper())] 
      data_ingredients_list =list(df_dish_all_rows['ingredients'])
      print("1111111",data_ingredients_list)
      data_ingredients_random = np.random.choice(data_ingredients_list)

      #latest message from user
      latest_msg = tracker.latest_message.get("text")
      print("xyz11111111", latest_msg)
      var1 =latest_msg.split("cook")[1].split("burger")[0].strip()

      if len(var1)>0:
        conditions2=var1
        df_dish_all_r1 = df_dish_all_rows[df_dish_all_rows['dish'].str.contains(conditions2.upper())] 
        if len(df_dish_all_r1)>0:
          data_ingredients_lst1 =list(df_dish_all_r1['ingredients'])
          data_ingredients_r1 = np.random.choice(data_ingredients_lst1)
          print("22222222",data_ingredients_r1)

          msg1 = "Ingredients for selected {}! Ingredients: {}:".format(conditions,data_ingredients_r1)
          dispatcher.utter_message(msg1)
          return []

        else:
          print("3333333333",data_ingredients_random)

          msg = "Ingredients for selected {}! Ingredients: {}:".format(conditions,data_ingredients_random)
          dispatcher.utter_message(msg)
          return []



      else:
        print("44444444444",data_ingredients_random)

        msg = "Ingredients for selected {}! Ingredients: {}:".format(conditions,data_ingredients_random)
        dispatcher.utter_message(msg)
        return []

        
        
class ActionDbTime(Action):
 
    def name(self):
      return "action_times"

    def run(self, dispatcher, tracker, domain):
      
      conditions=tracker.get_slot('food')
      df_dish_all_rows = df1[df1['dish'].str.contains(conditions.upper())] 
      data_times_list =list(df_dish_all_rows['times'])
      #print("1111111",data_times_list)
      data_times_random = np.random.choice(data_times_list)
      print("222222222",data_times_random)

      msg = "Times for selected {}! {}:".format(conditions,data_times_random)
      dispatcher.utter_message(msg)
      return []        
        
        
     
        

class ActionDbTemp(Action):
    

    def name(self):
      return "action_temp"

    def run(self, dispatcher, tracker, domain):
      
      conditions=tracker.get_slot('food') 
      df_dish_all_rows = df1[df1['dish'].str.contains(conditions.upper())]
      data_temp_list = list(df_dish_all_rows['temperature'])
      #print("1111111",data_temp_list)
      data_temp_random = np.random.choice(data_temp_list)
      print("222222222",data_temp_random)

      msg = "Temperature for selected {} is {}!".format(conditions,data_temp_random)
      dispatcher.utter_message(msg)
      return []


class ActionJoke(Action):
    
    def name(self):
        # define the name of the action which can then be included in training stories
        return "action_joke"

    def run(self, dispatcher, tracker, domain):
        # what your action should do
        request = requests.get('http://api.icndb.com/jokes/random').json() #make an apie call
        joke = request['value']['joke'] #extract a joke from returned json response
        dispatcher.utter_message(joke) #send the message back to the user
        return []
        
        
class ActionRecipeRequest(Action):

    def name(self) -> Text:
      return "action_recipe"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
      """
      :type dispatcher: object
      """
      food = tracker.get_slot('food')
      api_key = '7075a0af87f14d49b970760944d77ef3'
      params = {'query': food , 'apiKey': api_key}
      url = 'https://api.spoonacular.com/recipes/complexSearch'
      status = requests.get(url, params)
      response = status.json()
      recipe = response['results'][0]
      url2 = 'https://api.spoonacular.com/recipes/716429/information?includeNutrition=false'
      params2 = {'id': recipe['id'], 'apiKey': api_key}
      res2 = requests.get(url2, params2)
      json2 = res2.json()
      link_recipe = 'The title of the recipe is: ' + json2['title'] + ' The link to the recipe is: ' + json2['sourceUrl']


      dispatcher.utter_message('Here is your recipe ' + link_recipe)


      return []
