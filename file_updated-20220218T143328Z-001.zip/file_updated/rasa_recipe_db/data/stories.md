
## say goodbye
* goodbye
  - utter_goodbye

  
## story greet_
* greet
  - utter_ask
  
  
## bot challenge
* bot_challenge
  - utter_iamabot
  
  
## story request_recipe_cook_burger
* request_recipes{"recipes":"recipe","food":"burger"}
  - utter_burger_recipe

## story request_recipe_cook_pasta
* request_recipes{"recipes":"recipe", "food":"pasta"}
  - utter_pasta_recipe
  
## story request_recipe_cook_pizza
* request_recipes{"recipes":"recipe", "food":"pizza"}
  - utter_pizza_recipe

## story request_ingredients_cook_burger
* request_ingredients{"ingredients":"ingredient","food":"burger"}
  - action_ingredients

## story request_ingredients_cook_pasta
* request_ingredients{"ingredients":"ingredient", "food":"pasta"}
  - action_ingredients

## story request_ingredients_cook_pizza
* request_ingredients{"ingredients":"ingredient", "food":"pizza"}
  - action_ingredients
  
## story request_recipe_cook_veg_burger
* request_recipes{"recipes":"recipe", "vegs":"veg", "food":"burger"}
  - utter_veg_burger_recipe

## story request_recipe_cook_veg_pasta
* request_recipes{"recipes":"recipe", "vegs":"veg", "food":"pasta"}
  - utter_veg_pasta_recipe
  
## story request_recipe_cook_veg_pizza
* request_recipes{"recipes":"recipe", "vegs":"veg", "food":"pizza"}
  - utter_veg_pizza_recipe
  
  
## story request_recipe_cook_non_veg_burger
* request_recipes{"recipes":"recipe", "non-vegs":"non-veg", "food":"burger"}
  - utter_non_veg_burger_recipe

## story request_recipe_cook_non_veg_pasta
* request_recipes{"recipes":"recipe", "non-vegs":"non-veg", "food":"pasta"}
  - utter_non_veg_pasta_recipe
  
## story request_recipe_cook_non_veg_pizza
* request_recipes{"recipes":"recipe", "non-vegs":"non-veg", "food":"pizza"}
  - utter_non_veg_pizza_recipe
  
  

## story request_ingredients_cook_veg_burger
* request_ingredients{"ingredients":"ingredient","vegs":"veg", "food":"burger"}
  - utter_veg_burger_ingredients

## story request_ingredients_cook_veg_pasta
* request_ingredients{"ingredients":"ingredient", "vegs":"veg", "food":"pasta"}
  - utter_veg_pasta_ingredients

## story request_ingredients_cook_veg_pizza
* request_ingredients{"ingredients":"ingredient", "vegs":"veg", "food":"pizza"}
  - utter_veg_pizza_ingredients



## story request_ingredients_cook_non_veg_burger
* request_ingredients{"ingredients":"ingredient","non-vegs":"non-veg", "food":"burger"}
  - utter_non_veg_burger_ingredients

## story request_ingredients_cook_non_veg_pasta
* request_ingredients{"ingredients":"ingredient", "non-vegs":"non-veg", "food":"pasta"}
  - utter_non_veg_pasta_ingredients

## story request_ingredients_cook_non_veg_pizza
* request_ingredients{"ingredients":"ingredient", "non-vegs":"non-veg", "food":"pizza"}
  - utter_non_veg_pizza_ingredients


## story ask_temps_cook_burger
* ask_temps{"temps":"temperature","food":"burger"}
  - utter_default_temp_burger

## story ask_temps_cook_pasta
* ask_temps{"temps":"temperature", "food":"pasta"}
  - utter_default_temp_pasta
  
## story ask_temps_cook_pizza
* ask_temps{"temps":"temperature", "food":"pizza"}
  - utter_default_temp_pizza

## story ask_temps_cook_veg_burger
* ask_temps{"temps":"temperature","vegs":"veg","food":"burger"}
  - utter_default_temp_veg_burger

## story ask_temps_cook_veg_pasta
* ask_temps{"temps":"temperature", "vegs":"veg","food":"pasta"}
  - utter_default_temp_veg_pasta

## story ask_temps_cook_veg_pizza
* ask_temps{"temps":"temperature", "vegs":"veg","food":"pizza"}
  - utter_default_temp_veg_pizza


## story ask_temps_cook_non_veg_burger
* ask_temps{"temps":"temperature","non-vegs":"non-veg","food":"burger"}
  - utter_default_temp_non_veg_burger

## story ask_temps_cook_non_veg_pasta
* ask_temps{"temps":"temperature", "non-vegs":"non-veg","food":"pasta"}
  - utter_default_temp_non_veg_pasta

## story ask_temps_cook_non_veg_pizza
* ask_temps{"temps":"temperature", "non-vegs":"non-veg","food":"pizza"}
  - utter_default_temp_non_veg_pizza
  
  
  
  

  

## story ask_times_cook_burger
* ask_times{"times":"time","food":"burger"}
  - action_times

## story ask_times_cook_pasta
* ask_times{"times":"time", "food":"pasta"}
  - action_times
  
## story ask_times_cook_pizza
* ask_times{"times":"time", "food":"pizza"}
  - action_times
  
  
  
  
  
## story request_cook_burger_pasta_pizza
* multiple_food{"food":"burger" ,"food":"pasta" ,"food":"pizza"}
  - utter_fallback
  
 ## story request_cook_burger_pasta_
* multiple_food{"food":"burger" ,"food":"pasta"}
  - utter_fallback
  
 ## story request_cook_burger_pizza_
* multiple_food{"food":"burger" ,"food":"pizza"}
  - utter_fallback

 ## story request_cook_pasta_pizza_
* multiple_food{"food":"pasta" ,"food":"pizza"}
  - utter_fallback
  
  

## story request_recipe_cook_burger_pasta_pizza
* multiple_food{"recipes":"recipe","food":"burger" ,"food":"pasta" ,"food":"pizza"}
  - utter_fallback
  
 ## story request_recipe_cook_burger_pasta_
* multiple_food{"recipes":"recipe","food":"burger" ,"food":"pasta"}
  - utter_fallback
  
 ## story request_recipe_cook_burger_pizza_
* multiple_food{"recipes":"recipe","food":"burger" ,"food":"pizza"}
  - utter_fallback

 ## story request_recipe_cook_pasta_pizza_
* multiple_food{"recipes":"recipe","food":"pasta" ,"food":"pizza"}
  - utter_fallback
  
  
  
  
  ## story request_ingredients_cook_burger_pasta_pizza
* multiple_food{"ingredients":"ingredient","food":"burger" ,"food":"pasta" ,"food":"pizza"}
  - utter_fallback
  
 ## story request_ingredients_cook_burger_pasta_
* multiple_food{"ingredients":"ingredient","food":"burger" ,"food":"pasta"}
  - utter_fallback
  
 ## story request_ingredients_cook_burger_pizza_
* multiple_food{"ingredients":"ingredient","food":"burger" ,"food":"pizza"}
  - utter_fallback

 ## story request_ingredients_cook_pasta_pizza_
* multiple_food{"ingredients":"ingredient","food":"pasta" ,"food":"pizza"}
  - utter_fallback
  
  
  
  
## default fallback
* bot_challenge
  - action_default_fallback


## story_save_data_actions
* thanks_
  - utter_thanks
* affirm
  - action_data_save 


## story_thanks
* thanks_
  - utter_thanks
  
  

## story_thanks
* okk
  - utter_ask
  


  