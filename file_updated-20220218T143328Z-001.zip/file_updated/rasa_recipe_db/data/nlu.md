## intent:greet
- hey
- hello
- hi
- good morning
- good evening
- hey there

## intent:goodbye
- bye
- goodbye
- see you around
- see you later

## intent:affirm
- yes
- indeed
- of course
- that sounds good
- correct
- yes sure
- yeah

## intent:deny
- no
- never
- I don't think so
- don't like that
- no way
- not really

## intent:mood_great
- perfect
- very good
- great
- amazing
- wonderful
- I am feeling very good
- I am great
- I'm good

## intent:mood_unhappy
- sad
- very sad
- unhappy
- bad
- very bad
- awful
- terrible
- not very good
- extremely sad
- so sad

## intent:bot_challenge
- are you a bot?
- are you a human?
- am I talking to a bot?
- am I talking to a human?

## intent:thanks_
- thanks
- thank you
- Thanks
- Thank you

## intent:okk
- okk
- okay
- ok
- got it
- yeah


## intent:cook_food
- [pasta](food)
- [pasta](food)
- [pasta](food)
- [pasta](food)
- [burger](food)
- [burger](food)
- [burger](food)
- [burger](food)
- [pizza](food)
- [pizza](food)
- [pizza](food)
- [pizza](food)

## intent:request_recipes
- give me a [recipe](recipes)
- [recipe](recipes)
- please provide [recipe](recipes)
- provide [recipe](recipes)
- [recipe](recipes)
- cook [pasta](food)
- cook [burger](food)
- cook [pizza](food)
- how to cook [pasta](food)
- how to cook [burger](food)
- how to cook [pizza](food)
- how to cook [pasta](food)?
- how to cook [burger](food)?
- how to cook [pizza](food)?
- what are the [recipe](recipes)?
- what are the [recipe](recipes)
- what are the [recipe](recipes) to cook?
- what are the [recipe](recipes) to cook it?
- what are the [recipe](recipes) required?
- what are the [recipe](recipes) required to cook?
- what are the [recipe](recipes) required to cook it?
- give me a [recipe](recipes) for [pasta](food)
- [recipe](recipes) for [pasta](food)
- [recipe](recipes) to cook [pasta](food)
- [recipe](recipes) to cook [burger](food)
- [recipe](recipes) to cook [pizza](food)
- please provide [recipe](recipes) for [pasta](food)
- provide [recipe](recipes) for [pasta](food)
- [recipe](recipes) for [pasta](food)
- give me a [recipe](recipes) for [burger](food)
- [recipe](recipes) for [burger](food)
- please provide [recipe](recipes) for [burger](food)
- provide [recipe](recipes) for [burger](food)
- give me a [recipe](recipes) for [pizza](food)
- [recipe](recipes) for [pizza](food)
- please provide [recipe](recipes) for [pizza](food)
- provide [recipe](recipes) for [pizza](food)
- [recipe](recipes) for [pizza](food)
- what are the [recipe](recipes) to cook [burger](food)?
- what are the [recipe](recipes) to cook [pasta](food)?
- what are the [recipe](recipes) to cook [pizza](food)?
- give me a [recipe](recipes) for [veg](vegs) [pasta](food)
- [recipe](recipes) for [veg](vegs) [pasta](food)
- please provide [recipe](recipes) for [veg](vegs) [pasta](food)
- provide [recipe](recipes) for [veg](vegs) [pasta](food)
- [recipe](recipes) for [veg](vegs) [pasta](food)
- give me a [recipe](recipes) for [veg](vegs) [burger](food)
- [recipe](recipes) for [veg](vegs) [burger](food)
- please provide [recipe](recipes) for [veg](vegs) [burger](food)
- provide [recipe](recipes) for [veg](vegs) [burger](food)
- give me a [recipe](recipes) for [veg](vegs) [pizza](food)
- [recipe](recipes) for [veg](vegs) [pizza](food)
- please provide [recipe](recipes) for [veg](vegs) [pizza](food)
- provide [recipe](recipes) for [veg](vegs) [pizza](food)
- [recipe](recipes) for [veg](vegs) [pasta](food)
- [recipe](recipes) for [veg](vegs) [burger](food)
- what are the [recipe](recipes) to cook [veg](vegs) [burger](food)?
- what are the [recipe](recipes) to cook [veg](vegs) [pasta](food)?
- what are the [recipe](recipes) to cook [veg](vegs) [pizza](food)?

- give me a [recipe](recipes) for [non-veg](non-vegs) [pasta](food)
- [recipe](recipes) for [non-veg](non-vegs) [pasta](food)
- please provide [recipe](recipes) for [non-veg](non-vegs) [pasta](food)
- provide [recipe](recipes) for [non-veg](non-vegs) [pasta](food)
- [recipe](recipes) for [non-veg](non-vegs) [pasta](food)
- give me a [recipe](recipes) for [non-veg](non-vegs) [burger](food)
- [recipe](recipes) for [non-veg](non-vegs) [burger](food)
- please provide [recipe](recipes) for [non-veg](non-vegs) [burger](food)
- provide [recipe](recipes) for [non-veg](non-vegs) [burger](food)
- give me a [recipe](recipes) for [non-veg](non-vegs) [pizza](food)
- [recipe](recipes) for [non-veg](non-vegs) [pizza](food)
- please provide [recipe](recipes) for [non-veg](non-vegs) [pizza](food)
- provide [recipe](recipes) for [non-veg](non-vegs) [pizza](food)
- [recipe](recipes) for [non-veg](non-vegs) [pasta](food)
- [recipe](recipes) for [non-veg](non-vegs) [burger](food)
- what are the [recipe](recipes) to cook [non-veg](non-vegs) [burger](food)?
- what are the [recipe](recipes) to cook [non-veg](non-vegs) [pasta](food)?
- what are the [recipe](recipes) to cook [non-veg](non-vegs) [pizza](food)?

- give me a [recipe](recipes) for [non veg](non-vegs) [pasta](food)
- [recipe](recipes) for [non veg](non-vegs) [pasta](food)
- please provide [recipe](recipes) for [non veg](non-vegs) [pasta](food)
- provide [recipe](recipes) for [non veg](non-vegs) [pasta](food)
- [recipe](recipes) for [non veg](non-vegs) [pasta](food)
- give me a [recipe](recipes) for [non veg](non-vegs) [burger](food)
- [recipe](recipes) for [non veg](non-vegs) [burger](food)
- please provide [recipe](recipes) for [non veg](non-vegs) [burger](food)
- provide [recipe](recipes) for [non veg](non-vegs) [burger](food)
- give me a [recipe](recipes) for [non veg](non-vegs) [pizza](food)
- [recipe](recipes) for [non veg](non-vegs) [pizza](food)
- please provide [recipe](recipes) for [non veg](non-vegs) [pizza](food)
- provide [recipe](recipes) for [non veg](non-vegs) [pizza](food)
- [recipe](recipes) for [non veg](non-vegs) [pasta](food)
- [recipe](recipes) for [non veg](non-vegs) [burger](food)
- what are the [recipe](recipes) to cook [non veg](non-vegs) [burger](food)?
- what are the [recipe](recipes) to cook [non veg](non-vegs) [pasta](food)?
- what are the [recipe](recipes) to cook [non veg](non-vegs) [pizza](food)?




## intent:request_ingredients
- give me a [ingredient](ingredients)
- [ingredient](ingredients)
- please provide [ingredient](ingredients)
- provide [ingredient](ingredients)
- [ingredient](ingredients)
- [ingredient](ingredients) please
- what are the [ingredient](ingredients)?
- what are the [ingredient](ingredients)
- what are the [ingredient](ingredients) to cook?
- what are the [ingredient](ingredients) required to cook it?
- what are the [ingredient](ingredients) required?
- give me a [ingredient](ingredients) for [pasta](food)
- give me a [ingredient](ingredients) for [burger](food)
- give me a [ingredient](ingredients) for [pizza](food)
- [ingredient](ingredients) to cook [pizza](food)
- [ingredient](ingredients) to cook [burger](food)
- [ingredient](ingredients) to cook [pasta](food)
- [ingredient](ingredients) for [pasta](food)
- please provide [ingredient](ingredients) for [pasta](food)
- provide [ingredient](ingredients) for [pasta](food)
- [ingredient](ingredients) for [pasta](food)
- give me a [ingredient](ingredients) for [burger](food)
- [ingredient](ingredients) for [burger](food)
- please provide [ingredient](ingredients) for [burger](food)
- provide [ingredient](ingredients) for [burger](food)
- [ingredient](ingredients) for [burger](food)
- [ingredient](ingredients) for [pizza](food)
- please provide [ingredient](ingredients) for [pizza](food)
- provide [ingredient](ingredients) for [pizza](food)
- [ingredient](ingredients) for [pizza](food)
- what are the [ingredient](ingredients) to cook [burger](food)?
- what are the [ingredient](ingredients) to cook [pasta](food)?
- what are the [ingredient](ingredients) to cook [pizza](food)?
- give me a [ingredient](ingredients) for [veg](vegs) [pasta](food)
- [ingredient](ingredients) for [veg](vegs) [pasta](food)
- please provide [ingredient](ingredients) for [veg](vegs) [pasta](food)
- provide [ingredient](ingredients) for [veg](vegs) [pasta](food)
- [ingredient](ingredients) for [veg](vegs) [pasta](food)
- give me a [ingredient](ingredients) for [veg](vegs) [burger](food)
- [ingredient](ingredients) for [veg](vegs) [burger](food)
- please provide [ingredient](ingredients) for [veg](vegs) [burger](food)
- provide [ingredient](ingredients) for [veg](vegs) [burger](food)
- [ingredient](ingredients) for [veg](vegs) [burger](food)
- give me a [ingredient](ingredients) for [veg](vegs) [pizza](food)
- [ingredient](ingredients) for [veg](vegs) [pizza](food)
- please provide [ingredient](ingredients) for [veg](vegs) [pizza](food)
- provide [ingredient](ingredients) for [veg](vegs) [pizza](food)
- [ingredient](ingredients) for [veg](vegs) [pizza](food)
- what are the [ingredient](ingredients) to cook [veg](vegs) [burger](food)?
- what are the [ingredient](ingredients) to cook [veg](vegs) [pasta](food)?
- what are the [ingredient](ingredients) to cook [veg](vegs) [pizza](food)?

- give me a [ingredient](ingredients) for [non-veg](non-vegs) [pasta](food)
- [ingredient](ingredients) for [non-veg](non-vegs) [pasta](food)
- please provide [ingredient](ingredients) for [non-veg](non-vegs) [pasta](food)
- provide [ingredient](ingredients) for [non-veg](non-vegs) [pasta](food)
- [ingredient](ingredients) for [non-veg](non-vegs) [pasta](food)
- give me a [ingredient](ingredients) for [non-veg](non-vegs) [burger](food)
- [ingredient](ingredients) for [non-veg](non-vegs) [burger](food)
- please provide [ingredient](ingredients) for [non-veg](non-vegs) [burger](food)
- provide [ingredient](ingredients) for [non-veg](non-vegs) [burger](food)
- [ingredient](ingredients) for [non-veg](non-vegs) [burger](food)
- give me a [ingredient](ingredients) for [non-veg](non-vegs) [pizza](food)
- [ingredient](ingredients) for [non-veg](non-vegs) [pizza](food)
- please provide [ingredient](ingredients) for [non-veg](non-vegs) [pizza](food)
- provide [ingredient](ingredients) for [non-veg](non-vegs) [pizza](food)
- [ingredient](ingredients) for [non-veg](non-vegs) [pizza](food)
- what are the [ingredient](ingredients) to cook [non-veg](non-vegs) [burger](food)?
- what are the [ingredient](ingredients) to cook [non-veg](non-vegs) [pasta](food)?
- what are the [ingredient](ingredients) to cook [non-veg](non-vegs) [pizza](food)?

- give me a [ingredient](ingredients) for [non veg](non-vegs) [pasta](food)
- [ingredient](ingredients) for [non veg](non-vegs) [pasta](food)
- please provide [ingredient](ingredients) for [non veg](non-vegs) [pasta](food)
- provide [ingredient](ingredients) for [non veg](non-vegs) [pasta](food)
- [ingredient](ingredients) for [non veg](non-vegs) [pasta](food)
- give me a [ingredient](ingredients) for [non veg](non-vegs) [burger](food)
- [ingredient](ingredients) for [non veg](non-vegs) [burger](food)
- please provide [ingredient](ingredients) for [non veg](non-vegs) [burger](food)
- provide [ingredient](ingredients) for [non veg](non-vegs) [burger](food)
- [ingredient](ingredients) for [non veg](non-vegs) [burger](food)
- give me a [ingredient](ingredients) for [non veg](non-vegs) [pizza](food)
- [ingredient](ingredients) for [non veg](non-vegs) [pizza](food)
- please provide [ingredient](ingredients) for [non veg](non-vegs) [pizza](food)
- provide [ingredient](ingredients) for [non veg](non-vegs) [pizza](food)
- [ingredient](ingredients) for [non veg](non-vegs) [pizza](food)
- what are the [ingredient](ingredients) to cook [non veg](non-vegs) [burger](food)?
- what are the [ingredient](ingredients) to cook [non veg](non-vegs) [pasta](food)?
- what are the [ingredient](ingredients) to cook [non veg](non-vegs) [pizza](food)?

## intent: ask_temps
- [temperature](temps)
- [temp](temps)
- what are the [temperature](temps) to cook?
- [temperature](temps) to cook?
- [temperature](temps) to cook
- [temperature](temps) for [pasta](food)
- [temp](temps) for [pasta](food)
- what are the [temperature](temps) to cook [pasta](food)?
- [temperature](temps) to cook [pasta](food)?
- [temperature](temps) to cook [pasta](food)
- [temperature](temps) for [burger](food)
- [temp](temps) for [burger](food)
- what are the [temperature](temps) to cook [burger](food)?
- [temperature](temps) to cook [burger](food)?
- [temperature](temps) to cook [burger](food)
- [temperature](temps) for [pizza](food)
- [temp](temps) for [pizza](food)
- what are the [temperature](temps) to cook [pizza](food)?
- [temperature](temps) to cook [pizza](food))?
- [temperature](temps) to cook [pizza](food)
- [temperature](temps) for [veg](vegs) [pasta](food)
- [temp](temps) for [veg](vegs) [pasta](food)
- what are the [temperature](temps) to cook [veg](vegs) [pasta](food)?
- [temperature](temps) to cook [veg](vegs) [pasta](food)?
- [temperature](temps) to cook [veg](vegs) [pasta](food)
- [temperature](temps) for [veg](vegs) [burger](food)
- [temp](temps) for [veg](vegs) [burger](food)
- what are the [temperature](temps) to cook [veg](vegs) [burger](food)?
- [temperature](temps) to cook [veg](vegs) [burger](food)?
- [temperature](temps) to cook [veg](vegs) [burger](food)
- [temperature](temps) for [veg](vegs) [pizza](food)
- [temp](temps) for [veg](vegs) [pizza](food)
- what are the [temperature](temps) to cook [veg](vegs) [pizza](food)?
- [temperature](temps) to cook [veg](vegs) [pizza](food)?
- [temperature](temps) to cook [veg](vegs) [pizza](food)


- what are the [temperature](temps) to cook [non-veg](non-vegs) [pasta](food)?
- [temperature](temps) to cook [non-veg](non-vegs) [pasta](food)?
- [temperature](temps) to cook [non-veg](non-vegs) [pasta](food)
- [temperature](temps) for [non-veg](non-vegs) [burger](food)
- [temp](temps) for [non-veg](non-vegs) [burger](food)
- what are the [temperature](temps) to cook [non-veg](non-vegs) [burger](food)?
- [temperature](temps) to cook [non-veg](non-vegs) [burger](food)?
- [temperature](temps) to cook [non-veg](non-vegs) [burger](food)
- [temperature](temps) for [non-veg](non-vegs) [pizza](food)
- [temp](temps) for [non-veg](non-vegs) [pizza](food)
- what are the [temperature](temps) to cook [non-veg](non-vegs) [pizza](food)?
- [temperature](temps) to cook [non-veg](non-vegs) [pizza](food)?
- [temperature](temps) to cook [non-veg](non-vegs) [pizza](food)


- what are the [temperature](temps) to cook [non veg](non-vegs) [pasta](food)?
- [temperature](temps) to cook [non veg](non-vegs) [pasta](food)?
- [temperature](temps) to cook [non veg](non-vegs) [pasta](food)
- [temperature](temps) for [non veg](non-vegs) [burger](food)
- [temp](temps) for [non veg](non-vegs) [burger](food)
- what are the [temperature](temps) to cook [non veg](non-vegs) [burger](food)?
- [temperature](temps) to cook [non veg](non-vegs) [burger](food)?
- [temperature](temps) to cook [non veg](non-vegs) [burger](food)
- [temperature](temps) for [non veg](non-vegs) [pizza](food)
- [temp](temps) for [non veg](non-vegs) [pizza](food)
- what are the [temperature](temps) to cook [non veg](non-vegs) [pizza](food)?
- [temperature](temps) to cook [non veg](non-vegs) [pizza](food)?
- [temperature](temps) to cook [non veg](non-vegs) [pizza](food)



## synonym:non veg
- non-veg


## intent: multiple_food
- [pizza](food) [burger](food) [pasta](food)
- [pasta](food) [pizza](food) [burger](food)

- cook [pizza](food) [burger](food) [pasta](food)
- cook [pizza](food), [burger](food), [pasta](food)
- [pasta](food), [pizza](food), and [burger](food)
- [pasta](food), [pizza](food) & [burger](food)
- [pizza](food) [burger](food) [pasta](food)
- how to cook [pasta](food) [pizza](food) and [burger](food)
- how to cook [pasta](food) [pizza](food) & [burger](food)
- how to cook [pizza](food) [burger](food) [pasta](food)
- [burger](food) [pasta](food)
- [burger](food), and [pasta](food)
- cook [burger](food) [pasta](food)

- [pizza](food) [burger](food)
- cook [pizza](food) and [burger](food)
- cook [pizza](food), [burger](food)

- cook [pizza](food) [pasta](food)
- cook [pizza](food) [pasta](food)
- cook [pizza](food) [pasta](food)

- [burger](food) and [pasta](food)
- cook  [burger](food) [pasta](food)
- cook [burger](food) [pasta](food)

- [pizza](food) & [burger](food)
- cook [pizza](food) [burger](food)
- cook [pizza](food) [burger](food)

- cook [pizza](food), [pasta](food)
- cook [pizza](food) [pasta](food)
- to cook [pizza](food) [pasta](food)
- cook [pizza](food) [pasta](food)
- cook [pizza](food), and [pasta](food)
- cook [pizza](food), [pasta](food)
- to cook [pizza](food) and [pasta](food)

- give me a [ingredient](ingredients) for [pasta](food), [burger](food), [pizza](food)
- give me a [ingredient](ingredients) for [pasta](food), [burger](food), and [pizza](food)
- give me a [ingredient](ingredients) for [pasta](food), [burger](food), & [pizza](food)
- give me a [ingredient](ingredients) for [pasta](food) [burger](food) [pizza](food)

- give me a [ingredient](ingredients) for [burger](food), [pizza](food)
- give me a [ingredient](ingredients) for [burger](food), and [pizza](food)
- give me a [ingredient](ingredients) for [burger](food), & [pizza](food)
- give me a [ingredient](ingredients) for [burger](food) [pizza](food)

- give me a [ingredient](ingredients) for [pasta](food), [pizza](food)
- give me a [ingredient](ingredients) for [pasta](food)), and [pizza](food)
- give me a [ingredient](ingredients) for [pasta](food), & [pizza](food)
- give me a [ingredient](ingredients) for [pasta](food) [pizza](food)

- give me a [ingredient](ingredients) for [pasta](food), [pizza](food)
- give me a [ingredient](ingredients) for [pasta](food), and [pizza](food)
- give me a [ingredient](ingredients) for [pasta](food), & [pizza](food)
- give me a [ingredient](ingredients) for [pasta](food) [pizza](food)


- [ingredient](ingredients) to cook [pasta](food), [burger](food), [pizza](food)
- [ingredient](ingredients) to cook [pasta](food), [burger](food), and [pizza](food)
- [ingredient](ingredients) to cook [pasta](food), [burger](food), & [pizza](food)
- [ingredient](ingredients) to cook [pasta](food) [burger](food) [pizza](food)

- [ingredient](ingredients) to cook [burger](food), [pizza](food)
- [ingredient](ingredients) to cook [burger](food), and [pizza](food)
- [ingredient](ingredients) to cook [burger](food), & [pizza](food)
- [ingredient](ingredients) to cook [burger](food) [pizza](food)

- [ingredient](ingredients) to cook [pasta](food), [pizza](food)
- [ingredient](ingredients) to cook [pasta](food)), and [pizza](food)
- [ingredient](ingredients) to cook [pasta](food), & [pizza](food)
- [ingredient](ingredients) to cook [pasta](food) [pizza](food)

- [ingredient](ingredients) to cook [pasta](food), [pizza](food)
- [ingredient](ingredients) to cook [pasta](food), and [pizza](food)
- [ingredient](ingredients) to cook [pasta](food), & [pizza](food)
- [ingredient](ingredients) to cook [pasta](food) [pizza](food)


- [ingredient](ingredients) for [pasta](food), [burger](food), [pizza](food)
- [ingredient](ingredients) for [pasta](food), [burger](food), and [pizza](food)
- [ingredient](ingredients) for [pasta](food), [burger](food), & [pizza](food)
- [ingredient](ingredients) for [pasta](food) [burger](food) [pizza](food)

- [ingredient](ingredients) for [burger](food), [pizza](food)
- [ingredient](ingredients) for [burger](food), and [pizza](food)
- [ingredient](ingredients) for [burger](food), & [pizza](food)
- [ingredient](ingredients) for [burger](food) [pizza](food)

- [ingredient](ingredients) for [pasta](food), [pizza](food)
- [ingredient](ingredients) for [pasta](food)), and [pizza](food)
- [ingredient](ingredients) for [pasta](food), & [pizza](food)
- [ingredient](ingredients) for [pasta](food) [pizza](food)

- [ingredient](ingredients) for [pasta](food), [pizza](food)
- [ingredient](ingredients) for [pasta](food), and [pizza](food)
- [ingredient](ingredients) for [pasta](food), & [pizza](food)
- [ingredient](ingredients) for [pasta](food) [pizza](food)


- please provide [ingredient](ingredients) for [pasta](food), [burger](food), [pizza](food)
- provide [ingredient](ingredients) for [pasta](food), [burger](food)
- what are the [ingredient](ingredients) to cook [burger](food), [pizza](food)?



- give me a [recipe](recipes) for [pasta](food), [burger](food), [pizza](food)
- give me a [recipe](recipes) for [pasta](food), [burger](food), and [pizza](food)
- give me a [recipe](recipes) for [pasta](food), [burger](food), & [pizza](food)
- give me a [recipe](recipes) for [pasta](food) [burger](food) [pizza](food)

- give me a [recipe](recipes) for [burger](food), [pizza](food)
- give me a [recipe](recipes) for [burger](food), and [pizza](food)
- give me a [recipe](recipes) for [burger](food), & [pizza](food)
- give me a [recipe](recipes) for [burger](food) [pizza](food)

- give me a [recipe](recipes) for [pasta](food), [pizza](food)
- give me a [recipe](recipes) for [pasta](food)), and [pizza](food)
- give me a [recipe](recipes) for [pasta](food), & [pizza](food)
- give me a [recipe](recipes) for [pasta](food) [pizza](food)

- give me a [recipe](recipes) for [pasta](food), [pizza](food)
- give me a [recipe](recipes) for [pasta](food), and [pizza](food)
- give me a [recipe](recipes) for [pasta](food), & [pizza](food)
- give me a [recipe](recipes) for [pasta](food) [pizza](food)


- [recipe](recipes) to cook [pasta](food), [burger](food), [pizza](food)
- [recipe](recipes) to cook [pasta](food), [burger](food), and [pizza](food)
- [recipe](recipes) to cook [pasta](food), [burger](food), & [pizza](food)
- [recipe](recipes) to cook [pasta](food) [burger](food) [pizza](food)

- [recipe](recipes) to cook [burger](food), [pizza](food)
- [recipe](recipes) to cook [burger](food), and [pizza](food)
- [recipe](recipes) to cook [burger](food), & [pizza](food)
- [recipe](recipes) to cook [burger](food) [pizza](food)

- [recipe](recipes) to cook [pasta](food), [pizza](food)
- [recipe](recipes) to cook [pasta](food)), and [pizza](food)
- [recipe](recipes) to cook [pasta](food), & [pizza](food)
- [recipe](recipes) to cook [pasta](food) [pizza](food)

- [recipe](recipes) to cook [pasta](food), [pizza](food)
- [recipe](recipes) to cook [pasta](food), and [pizza](food)
- [recipe](recipes) to cook [pasta](food), & [pizza](food)
- [recipe](recipes) to cook [pasta](food) [pizza](food)


- [recipe](recipes) for [pasta](food), [burger](food), [pizza](food)
- [recipe](recipes) for [pasta](food), [burger](food), and [pizza](food)
- [recipe](recipes) for [pasta](food), [burger](food), & [pizza](food)
- [recipe](recipes) for [pasta](food) [burger](food) [pizza](food)

- [recipe](recipes) for [burger](food), [pizza](food)
- [recipe](recipes) for [burger](food), and [pizza](food)
- [recipe](recipes) for [burger](food), & [pizza](food)
- [recipe](recipes) for [burger](food) [pizza](food)

- [recipe](recipes) for [pasta](food), [pizza](food)
- [recipe](recipes) for [pasta](food)), and [pizza](food)
- [recipe](recipes) for [pasta](food), & [pizza](food)
- [recipe](recipes) for [pasta](food) [pizza](food)

- [recipe](recipes) for [pasta](food), [pizza](food)
- [recipe](recipes) for [pasta](food), and [pizza](food)
- [recipe](recipes) for [pasta](food), & [pizza](food)
- [recipe](recipes) for [pasta](food) [pizza](food)


- please provide [recipe](recipes) for [pasta](food), [burger](food), [pizza](food)
- provide [recipe](recipes) for [pasta](food), [burger](food)
- what are the [recipe](recipes) to cook [burger](food), [pizza](food)?



## intent: ask_times
- [time](times)
- [time](times)
- what are the [time](times) to cook?
- [time](times) to cook?
- [time](times) to cook
- [time](times) for [pasta](food)
- what are the [time](times) to cook [pasta](food)?
- [time](times) to cook [pasta](food)?
- [time](times) to cook [pasta](food)
- [time](times) for [burger](food)
- what are the [time](times) to cook [burger](food)?
- [time](times) to cook [burger](food)?
- [time](times) to cook [burger](food)
- [time](times) for [pizza](food)
- what are the [time](times) to cook [pizza](food)?
- [time](times) to cook [pizza](food))?
- [time](times) to cook [pizza](food)


## synonym:time
- duration
- durations

