import sqlite3

def rasa_create_insert_db(food, temp, ingredients, recipes, durations):
    connection = sqlite3.connect('recipes_db.sqlite')
    cursor = connection.cursor()
    
    # Creating table
    #rasa_table ="""CREATE TABLE frecipes_v1(food TEXT, temp TEXT, ingredients TEXT, recipes TEXT, durations TEXT)"""

    #cursor.execute(rasa_table)
    #print("rasa_table created successfully")
    cursor.execute("""INSERT INTO frecipes_v1(food, temp, ingredients, recipes, durations) VALUES (?, ?, ?, ?, ?);""", (food, temp, ingredients, recipes, durations))

    # Display data inserted
    print("Data Inserted in the table: ")
    data=cursor.execute('''SELECT * FROM frecipes_v1''')
    for row in data:
        print(row)
  
    connection.commit()
    connection.close()
    
    
    
#if __name__ == '__main__':
#    rasa_create_insert_db("burger", "28 *c", "onion, Chopped, clove garlic, tomatoes", "1 onion, Chopped, 4 clove garlic, 3 tomatoes", "4500 sec")
    
