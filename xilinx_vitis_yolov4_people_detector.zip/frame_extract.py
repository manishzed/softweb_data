"""frame_extract.py

This code implements the Camera class, which encapsulates code to
handle IP CAM, USB webcam or the Jetson onboard camera.  In
addition, this Camera class is further extended to take a video
file or an image file as input.
"""

import logging
import threading
import subprocess
import numpy as np
import cv2
import glob
import os

# The following flag ise used to control whether to use a GStreamer
# pipeline to open USB webcam source.  If set to False, we just open
# the webcam using cv2.VideoCapture(index) machinery. i.e. relying
# on cv2's built-in function to capture images from the webcam.
USB_GSTREAMER = True


class FrameExtract:
    """
            0: rtsp
            1: camera
            2: video
            3: images
    """

    def __init__(self, type_: int, uri: str, width: int, height: int, latency: int, interpolation, folder_path: str):
        if uri is None:
            uri = ""
        if width is None:
            width = 0
        if height is None:
            height = 0
        if latency is None:
            latency = 0
        if type_ not in [0, 1, 2] and folder_path is None and not os.path.exists(folder_path):
            assert "Please provide folder path"
        self.type = type_
        self.uri = uri
        self.cap = None
        self.width = width
        self.height = height
        self.latency = latency
        self.interpolation = interpolation
        self.folder_path = folder_path

    def read_rtsp(self):
        """Open an RTSP URI (IP CAM)."""
        gst_elements = str(subprocess.check_output('gst-inspect-1.0'))
        if 'avdec_h264' in gst_elements:
            gst_str = ('rtspsrc location={} latency={} ! '
                       'rtph264depay ! h264parse ! avdec_h264 ! '
                       'videoconvert ! appsink').format(self.uri, self.latency)
        else:
            raise RuntimeError('H.264 decoder not found!')
        self.cap = cv2.VideoCapture(gst_str, cv2.CAP_GSTREAMER)

    def read_camera(self):
        """
        Read provided uri
        """
        #'/dev/video0'
        self.cap = cv2.VideoCapture(self.uri)

    def read_video(self):
        """
        Read provided uri
        """
        self.cap = cv2.VideoCapture(self.uri)

    def read_images(self):
        """
        Read Images from provided folder path
        """
        for image in glob.glob(os.path.join(self.folder_path, '*')):
            frame = cv2.imread(image)
            if self.width and self.height:
                if self.interpolation:
                    try:
                        frame = cv2.resize(frame, (self.width, self.height), interpolation=self.interpolation)
                    except Exception as e:
                        logging.error(f"Error occurred while resizing frame. Error:{e}")
                else:
                    frame = cv2.resize(frame, (self.width, self.height))
            yield frame

    def capture_frame(self):
        """
        Capture frame from the cap
        """
        while True:
            ret, frame = self.cap.read()
            if not ret:
                assert "Not able to read provided source"
            if self.width and self.height:
                if self.interpolation:
                    try:
                        frame = cv2.resize(frame, (self.width, self.height), interpolation=self.interpolation)
                    except Exception as e:
                        logging.error(f"Error occurred while resizing frame. Error:{e}")
                else:
                    frame = cv2.resize(frame, (self.width, self.height))
            yield frame

    def read_frame(self):
        """
        Read frame and crate generator base on provided type
        """
        if self.type == 0:
            self.read_rtsp()
            #self.capture_frame()
        if self.type == 1:
            self.read_camera()
            #self.capture_frame()
        if self.type == 2:
            self.read_video()
            #self.capture_frame()
        if self.type == 3:
            self.read_images()



