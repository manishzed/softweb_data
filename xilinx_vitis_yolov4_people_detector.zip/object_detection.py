# USAGE
# python object_detection.py

import os
import sys
import cv2
import vart
import xir
import json
import logging
import numpy as np
from imutils.video import FPS
from tracker import CentroidTracker
from helper import class_name_list, anchor_list
from frame_extract import FrameExtract

sys.path.append(os.path.abspath('../'))
sys.path.append(os.path.abspath('./'))
from vitis_ai_vart.objectdetect import ObjectDetect
from vitis_ai_vart.utils import get_child_subgraph_dpu

"""
        0: rtsp
        1: camera
        2: video
        3: images
"""
config_json = open('config.json')
cfg_data = json.load(config_json)

type = cfg_data['cfg']["type"]
uri = cfg_data['cfg']["uri"]
folder_path = cfg_data['cfg']["folder_path"]
resize_width = cfg_data['cfg']["resize_width"]
resize_height = cfg_data['cfg']["resize_height"]
rtsp_latency = cfg_data['cfg']["rtsp_latency"]
resize_interpolation = cfg_data['cfg']["resize_interpolation"]
det_threshold = cfg_data['cfg']["det_threshold"]
nms_threshold = cfg_data['cfg']["nms_threshold"]
densebox_xmodel = cfg_data['cfg']["densebox_xmodel"]
out_video_path = cfg_data['cfg']["out_video_path"]
show_output = cfg_data['cfg']["show_output"]
save_video = cfg_data['cfg']["save_video"]

def str2bool(s):
  return s.lower() in ("true")

show_output = str2bool(show_output)
save_video = str2bool(save_video)

# Initialize Vitis-AI/DPU based face detector
densebox_graph = xir.Graph.deserialize(densebox_xmodel)
densebox_subgraphs = get_child_subgraph_dpu(densebox_graph)
#assert len(densebox_subgraphs) == 1 # only one DPU kernel
densebox_dpu = vart.Runner.create_runner(densebox_subgraphs[0],"run")

# list of class names
class_names = class_name_list()
# list of anchor boxs
anchor_list = anchor_list()

anchor_float = [float(x) for x in anchor_list]
anchors = np.array(anchor_float).reshape(-1, 2)
dpu_face_detector = ObjectDetect(densebox_dpu, class_names, anchors, det_threshold, nms_threshold)
dpu_face_detector.start()

frame_extract_obj = FrameExtract(type, uri, resize_width, resize_height, rtsp_latency,
                                 resize_interpolation, folder_path)
ct_obj = CentroidTracker(maxDisappeared=35)

# start the FPS counter
fps = FPS().start()
if len(out_video_path.split(".")) <= 1:
    out_video_name = os.path.join(out_video_path, "out.mp4")
else:
    if out_video_path.split(".")[1] != "mp4":
        assert "please provide mp4 in out video"
    else:
        out_video_name = out_video_path
if save_video:
    out_mp4 = cv2.VideoWriter(out_video_name,cv2.VideoWriter_fourcc('M','P','4','V'), 10, (768, 432))

count = 0
frame_extract_obj.read_frame()
for frame in frame_extract_obj.capture_frame():
    # Capture image from camera
    print("Count",count)
    if count % 2 == 0:
        # Camera provided BGR, and DPU needs RGB
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        imgHeight = frame_rgb.shape[0]
        imgWidth  = frame_rgb.shape[1]

        # Vitis-AI/DPU based face detector
        boxes, scores, classes = dpu_face_detector.process(frame_rgb)

        rects = []
        # loop over the faces
        for _box, _score, _class_num in zip(boxes, scores, classes):
            _name = class_names[_class_num]
            _score = int(_score*100)
            top,left,bottom,right = _box.astype(int)
            box_height = bottom-top
            box_width = right-left

            # adjust box size
            adjustment = 0.2
            top    += int(adjustment*box_height)
            bottom -= int(adjustment*box_height)
            left   += int(adjustment*box_width)
            right  -= int(adjustment*box_width)

            box_updated = np.array((left, top, right, bottom))
            rects.append(box_updated)

            # draw a bounding box surrounding the object so we can
            color = (64, 64, 255)
            cv2.rectangle( frame, (left,top), (right,bottom), color, 4)
            cv2.putText(frame, f"{_score}% {_name}",
                        (left+8,bottom-8), cv2.FONT_HERSHEY_SIMPLEX,
                        0.8, color, 2, cv2.LINE_AA)
            _, _ = ct_obj.update(rects)
    else:
        objects, bbox = ct_obj.update(rects)
        for box in list(bbox.values()):
            x1, y1, x2, y2 = box
            cv2.rectangle(frame, (x1, y1), (x2, y2), (255, 255, 0), 2)

    count += 1
    # Update the FPS counter
    fps.update()
    fps.stop()
    fps_count = fps.fps()
    print("FPS",fps_count)
    color = (255, 255, 255)
    cv2.putText(frame, f"FPS: {fps_count:.2f}", (8, 24), cv2.FONT_HERSHEY_SIMPLEX,
                                        0.5, color, 2, cv2.LINE_AA)

    # Display the processed image
    if save_video:
        out_mp4.write(frame)

    if show_output:
        cv2.imshow('output', frame)
        key = cv2.waitKey(1) & 0xFF

        # if the `q` key was pressed, break from the loop
        if key == ord("q"):
            break

# Stop the timer and display FPS information
fps.stop()
#print("FPS",fps_count)
# Stop the face detector
dpu_face_detector.stop()
del densebox_dpu

# Cleanup
cv2.destroyAllWindows()
