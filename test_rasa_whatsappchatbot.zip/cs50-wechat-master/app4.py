from flask import Flask,render_template,request,session,redirect
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename
from datetime import datetime
import os
import json
import mysql.connector
from datetime import datetime, timedelta
from flask import *
from flask_session import Session
import queue
from wtforms import StringField
from wtforms.validators import DataRequired
from flask_wtf import FlaskForm
import base64
from io import BytesIO

app = Flask(__name__)
app.config["DEBUG"] = True
app.config['SQLALCHEMY_DATABASE_URI']= 'mysql+pymysql://root:Softweb#135@localhost:3306/chatapp'
app.config["SQLALCHEMY_POOL_RECYCLE"] = 299
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = app.root_path + '/static/img/'
app.config['PERMANENT_SESSION_LIFETIME'] =  timedelta(minutes=2)
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
app.secret_key = 'silent'
Session(app)
db = SQLAlchemy(app)
session_started=True
class Login(db.Model):
  Id = db.Column(db.Integer,primary_key=True)
  username = db.Column(db.String(100),unique=False,nullable=False)
  password = db.Column(db.String(100),unique=False,nullable=False)

class Contact(db.Model):
  Id = db.Column(db.Integer,primary_key=True)
  sender = db.Column(db.String(100),unique=False,nullable=False)
  reciver = db.Column(db.String(100),unique=False,nullable=False)


class Message(db.Model):
  Id = db.Column(db.Integer,primary_key=True)
  sender = db.Column(db.String(100),unique=False,nullable=False)
  msg = db.Column(db.String(100),unique=False,nullable=False)
  reciver = db.Column(db.String(100),unique=False,nullable=False)
  dateTime = db.Column(db.String(100),unique=False,nullable=False)
  image_base64 = db.Column(db.String(1000),unique=False,nullable=True)

@app.before_request
def make_session_permanent():
    session.permanent = True
    app.permanent_session_lifetime = timedelta(minutes=2)

@app.route('/', methods=['GET','POST'])
def index():
  if 'user_session' in session:
    pass
  else:
    global session_started
    session_started=False
    message=""
    return redirect('/login')
  if request.method == 'POST':
    newFriend = request.form.get('newFriend').lower().strip()

    select = Contact.query.filter_by(sender=session['user_session'],reciver=newFriend).first()
    if select != None or newFriend == session['user_session']:
      errorMsg = newFriend + ' is already in your contact list.'
      return render_template('login.html',errorMsg=errorMsg)#('<h1>Error</h1>')

    select = Login.query.filter_by(username=newFriend).first()
    if select == None:
      errorMsg = 'No user available. Kindly check your friends username.'
      return render_template('login.html',errorMsg=errorMsg)#('<h1>Error</h1>')

    entry = Contact(
      sender=session['user_session'],
      reciver=newFriend
    )
    entry1 = Contact(
      sender=newFriend,
      reciver=session['user_session']
    )

    db.session.add(entry)
    db.session.add(entry1)
    db.session.commit()

  checkImg = os.path.isfile('./static/img/' + session['user_session'] + '.jpg')
  select = Contact.query.filter_by(sender=session['user_session']).all()
  if not checkImg:
    return render_template('chat_app3.html',select=select,user=session['user_session'],checkImg=checkImg)
  print("--------------user---------",session['user_session'])
  return render_template('chat_app3.html',len=len(select),len_1=0,select=select,user=session['user_session'], reciver_1='false')
  #return render_template("login.html", len = len(select), select = select)

@app.route('/<string:sender>-<string:reciver>', methods=['GET','POST'])
def chat(sender,reciver):
  if 'user_session' in session:
    pass
  else:
    global session_started
    session_started=False
    message=""
    return redirect('/login')
  if request.method == 'POST':
    if request.files['fileImg'].filename != '':
      fileImg = request.files['fileImg']
      fileImg.save(secure_filename(fileImg.filename))
      image = open(app.root_path +"\\"+ fileImg.filename, 'rb')
      image_read = image.read()
      image_encode = base64.b64encode(image_read)
      print(image_encode)
      DateTime = datetime.now().strftime("%d.%m.%y %H:%M")
      entry = Message(
        sender=session['user_session'],
        msg="",
        reciver=reciver,
        dateTime=DateTime,
        image_base64=image_encode
      )
      db.session.add(entry)
      db.session.commit()

      select = Contact.query.filter_by(sender=session['user_session']).all()
      selectMsg = Message.query.filter(
        sender==session['user_session'] or sender==reciver,
        reciver==reciver or reciver==session['user_session'],
      ).all()
      return render_template('chat_app3.html',select=select,selectMsg=selectMsg,
        sender=sender, reciver=reciver, reciver_1='true',  len=len(select),
         user=session['user_session'])
    else:
      msg = request.form.get('msg')
      DateTime = datetime.now().strftime("%d.%m.%y %H:%M")
      entry = Message(
        sender=session['user_session'],
        msg=msg,
        reciver=reciver,
        dateTime=DateTime,
        image_base64=""
      )
      print("***************Entry***********",entry)
      db.session.add(entry)
      db.session.commit()

  select = Contact.query.filter_by(sender=session['user_session']).all()
  selectMsg = Message.query.filter(
    sender==session['user_session'] or sender==reciver,
    reciver==reciver or reciver==session['user_session'],
  ).all()
  print("--------------------ELSE-------------------",selectMsg[-1].__dict__)
  return render_template(
    'chat_app3.html',
    select=select,
    selectMsg=selectMsg,
    sender=sender,
    reciver=reciver,
    reciver_1='true',
    len_1=len(selectMsg),
    len=len(select),
    user=session['user_session']
  )
  #return {"1":1}


@app.route('/@<string:sender>-<string:reciver>')
def dataProvider(sender,reciver):
  #session['user_session']='piyush'
  selectMsg = Message.query.filter(
    sender==session['user_session'] or sender==reciver,
    reciver==reciver or reciver==session['user_session'],
  ).all()
  senderD = []
  msgD = []
  reciverD = []
  dateTimeD = []
  image_base64=[]
  jsonP = {}
  for n in selectMsg:
    if n.reciver in [sender,reciver] and n.sender in [sender,reciver]:
      senderD.append(n.sender)
      msgD.append(n.msg)
      reciverD.append(n.reciver)
      dateTimeD.append(n.dateTime)
      image_base64.append(n.image_base64)
  jsonP['sender'] = senderD
  jsonP['msg'] = msgD
  jsonP['reciver'] = reciverD
  jsonP['dateTime'] = dateTimeD
  jsonP['image_base64'] = image_base64
  return json.dumps(jsonP)

@app.route('/login',methods=['GET','POST'])
def login():
  message=""
  if not session_started:
    message="true"
  print("--------------------LOGIN-----------------",session_started)
  return render_template('login.html', message=message)

@app.route('/login/<string:var>',methods=['GET','POST'])
def loginCheck(var):
  if var == '0':
    if request.method == 'POST':
      username = request.form.get('username').lower().strip()
      password = request.form.get('password')
      confirmPassword = request.form.get('confirmPassword')

      if password != confirmPassword:
        errorMsg = 'Confirm Password is not match.'
        return render_template('login.html',errorMsg=errorMsg)#('<h1>Error</h1>')

      # Unique username
      select = Login.query.filter_by(username=username).first()

      if select != None:
          errorMsg = 'Username is already exist.'
          return render_template('login.html',errorMsg=errorMsg)#('<h1>Error</h1>')

      if select != None and not check_password_hash(select.password, password):
        errorMsg = 'Username is already exist.'
        return render_template('login.html',errorMsg=errorMsg)#('<h1>Error</h1>')

      entry = Login(
        username = username,
        password = generate_password_hash(password),
      )

      db.session.add(entry)
      db.session.commit()

      session['user_session'] = username
      return redirect('/')

  else:

    if request.method == 'POST':
      username = request.form.get('username').lower().strip()
      password = request.form.get('password')
      select = Login.query.filter_by(username=username).first()

      if select == None or not check_password_hash(select.password, password):
        errorMsg = 'Username or password is wrong.'
        return render_template('login.html',errorMsg=errorMsg)#('<h1>Error</h1>')

      flash("you are successfuly logged in")
      session['user_session'] = select.username
      return redirect('/')
  message=""
  return render_template('login.html', message=message)

@app.route('/logout')
def logout():
  if 'user_session' in session:
    #print("************************",session['user_session'])
    session.pop('user_session')
    # print("--------------------LOGOUT-----------------",session_started)
    return redirect('/login')

@app.route('/<string:sender>',methods=['GET','POST'])
def edit(sender):
  if 'user_session' in session:
    pass
  else:
    global session_started
    session_started=False
    message=""
    return redirect('/login')

  if request.method == 'POST':
    fileImg = request.files['fileImg']
    fileImg.save(os.path.join(app.config['UPLOAD_FOLDER'],secure_filename(session['user_session']+'.jpg')))
    select = Login.query.filter_by(username=session['user_session']).first()
    return render_template("edit.html",user=select)

  select = Login.query.filter_by(username=session['user_session']).first()
  return render_template("edit.html",user=select)

@app.route('/view-<string:reciver>')
def view(reciver):
  print("-----------------RECIVER--------------------",reciver)
  select = Login.query.filter_by(username=reciver).first()
  return render_template("view.html",user=select)

@app.route('/error')
def error():
    return redirect('/login')

if __name__ == '__main__':
  #app.run(host='192.168.4.124', port=5000, debug=True)
  app.run(port=5000, debug=True)