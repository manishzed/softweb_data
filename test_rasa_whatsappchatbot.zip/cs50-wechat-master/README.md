# WeChat - Web Chat Application
<img src="https://github.com/shaikhmudassir/cs50-wechat/blob/master/static/img/7.JPG" width=800 width=800>

This is the final project of CS50 made in Flask Framework. It gives real time chat experience. It uses Centralized database for message fetching.
WeChat is the new web chatting application.Where, we can chat with our Colleague and Friends on any platform.

## Visit
You can visit and create your free account : <a href="https://shaikhmudassir.pythonanywhere.com">WeChat</a><br>
This application is deployed on free hosting platform pythonanywhere.com that’s why it may be down or migrate to another platform.

## Video Guide
https://youtu.be/7ldQT-jy2uw

<div align="center"><h4>Created by Shaikh Mudassir</h4></div>
