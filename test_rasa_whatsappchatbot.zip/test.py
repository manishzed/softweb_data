import json
from flask import Flask, request, render_template, Response
import requests
import json
import logging
import requests

app = Flask(__name__, template_folder='template')

@app.route('/check', methods = ['GET'])
def check():
    return "This is a test message"

app.run(host="0.0.0.0", port=5432, debug=True)
