import requests
import json
apikey= "nnnIFP_sandbox"
ngrok_link="https://de74-111-93-95-94.ngrok.io"
## Connecting webhook to Sandbox and Flask

url_post="https://waba-sandbox.360dialog.io/v1/configs/webhook"
body = {
            "url":ngrok_link+"/webhook/wamessages"
        }
headers = {"D360-API-KEY":apikey, 'content-type': 'application/json'}

x = requests.post(url=url_post,data=json.dumps(body), headers = headers)
print("Status code for our request is: ", x.status_code)
print(" The URL registered on 360dialog platform", x.json())

